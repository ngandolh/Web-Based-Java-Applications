/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package controller.home;
//
//import dao.SanPhamDAO;
//import java.io.IOException;
//import java.io.PrintWriter;
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//import model.CartList;
//import model.SanPham;
//
///**
// *
// * @author ADMIN
// */
//@WebServlet(name = "Order", urlPatterns = {"/order"})
//public class Order extends HttpServlet {
//      private final String SHOPPAGE = "index.jsp";
//
//    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
//        try (PrintWriter out = response.getWriter()) {
//            String url = SHOPPAGE;
//            HttpSession session = request.getSession();
//            CartList cart = (CartList) session.getAttribute("CART");
//            if(cart == null) {
//                cart = new CartList();
//            }
//            String title = request.getParameter("cboProduct");
//            cart.addItemToCart(title);
//            session.setAttribute("CART", cart);
//            response.sendRedirect(url);
//        }
//    }
//
//}

//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//               processRequest(request, response);

//        String masp = request.getParameter("masp");
//        String soluongss = request.getParameter("soluong");
//        
////        int soluong = Integer.parseInt(request.getParameter("soluong"));
//        try {
//            int soluong = Integer.parseInt(soluongss);
//            HttpSession ss = request.getSession();
//            CartList cl = (CartList) ss.getAttribute("cartList");
////            int soluong = Integer.parseInt(soluongss);
//            if (cl != null) {
//                cl.addToCart(masp, soluong);
//            } else {
//                cl = new CartList();
//                cl.addToCart(masp, soluong);
//            }                                               
//          
//            ss.setAttribute("cartList", cl);
//            System.out.println("Size: " + cl.size());
//            RequestDispatcher rd = getServletContext().getRequestDispatcher("/index");
//            rd.forward(request, response);
//            response.sendRedirect("index");

//            HttpSession session = request.getSession();
//            CartList cart = (CartList) session.getAttribute("CART");
//            if (cart == null){
//            cart = new CartList();
//            }
//            cart.addToCart(masp, soluong);
//            session.setAttribute("CART", cart);
//            SanPhamDAO dao = new SanPhamDAO();
////            SanPham result = dao.searchByName(masp);
//        } catch (NumberFormatException ex) {
//                 log("Order NumberFormat:"+ex.getMessage());
////            System.out.println("e" + e.getMessage());
//
//        }
//    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
//    @Override
//    public String getServletInfo() {
//        return "Short description";
//    }// </editor-fold>
//@Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        processRequest(request, response);
//    }
//
//    /**
//     * Returns a short description of the servlet.
//     *
//     * @return a String containing servlet description
//     */
//    @Override
//    public String getServletInfo() {
//        return "Short description";
//}
   // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */

