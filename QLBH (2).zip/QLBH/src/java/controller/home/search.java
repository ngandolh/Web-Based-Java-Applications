/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.home;

import dao.SanPhamDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.SanPham;

/**
 *
 * @author ADMIN
 */
@WebServlet(name = "search", urlPatterns = {"/search"})
public class search extends HttpServlet {
//
//    /**
//     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
//     * methods.
//     *
//     * @param request servlet request
//     * @param response servlet response
//     * @throws ServletException if a servlet-specific error occurs
//     * @throws IOException if an I/O error occurs
//     */
//    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
//        try (PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
//            String keyword = request.getParameter("txtsearch");
//            String searchby = request.getParameter("searchby");
//            ArrayList<SanPham> list = SanPhamDAO.getSanPham(keyword,searchby);
//         if(list!=null && !list.isEmpty()){
//            out.println("<!DOCTYPE html>");
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Servlet search</title>");            
//            out.println("</head>");
//            out.println("<body><section>");
//            ServletContext context=getServletContext();
//            String tmp = context.getInitParameter("countryName");
//            out.println("<p>The website is deploying in" +tmp +"</p>");
//            ServletConfig servletconfig = getServletConfig();
//            String tmp2=servletconfig.getInitParameter("language");
//            out.println("<p>Language is used only in this page:" + tmp2 +"</p>");
//            for(SanPham sanpham : list){
//                out.println("<tr>");
//                out.println("<td>"+ sanpham.getMasp()+ "</td>");
//                out.println("<td>"+ sanpham.getTensp()+"</td>");
//                out.println("<td>"+ sanpham.getDongia()+"</td>");
//                out.println("<td><img src = "+sanpham.getHinhanh()+" class='controller.home'/></td>");
//                out.println("<td><a href = '#'> view detail </a></td>");
//                out.println("</tr>");
//            }
//            out.println("</body>");
//            out.println("</html>");
//        }
//         else out.println("nothing");
//        }
//    }

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //        if (request.getSession().getAttribute(name))

        try {
            SanPhamDAO daoSanPham = new SanPhamDAO();
            String searchName = request.getParameter("searchName");
            SanPham listSanPham = new SanPham();
            List<SanPham> searchResult = (List<SanPham>) daoSanPham.searchByName(searchName);
            for (SanPham sanPham : searchResult) {
                listSanPham = sanPham;
            }   
            request.setAttribute("SEARCH_RESULT", searchResult);
            request.setAttribute("listSanPham", listSanPham);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/view/home/search.jsp");
            rd.forward(request, response);
         //  response.sendRedirect("../view/home/search.jsp");
        } catch (Exception e) {
        }
}
}
