package controller.home;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import dao.TaiKhoanDAO;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.TaiKhoan;

/**
 *
 * @author ASUS
 */
//@WebServlet(urlPatterns = {"/home/login"}) để tạm
public class Login extends HttpServlet {


    private static final String ERROR="/view/home/login.jsp";
    private static final String AD="AD";
    private static final String ADMIN_PAGE="indexdanhmuc";
    private static final String US="US";
    private static final String USER_PAGE="index";
   
@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

                  RequestDispatcher rd = getServletContext().getRequestDispatcher("/view/home/login.jsp");
                  rd.forward(request, response);     
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String url= ERROR;
        try {
            String tentk= request.getParameter("tentk");
            String matkhau = request.getParameter("matkhau");
            TaiKhoanDAO dao = new TaiKhoanDAO();
            TaiKhoan loginUser = dao.checkLogin(tentk, matkhau);
            //xac thuc o day ne
            if(loginUser != null){
                HttpSession session = request.getSession();
                session.setAttribute("LOGIN_USER", loginUser);
                String nhomtk = loginUser.getNhomtaikhoan().getNhomtk();
                //phan quyen ne
                if(AD.equals(nhomtk)){
                    url =  ADMIN_PAGE;
                }else if(US.equals(nhomtk)){
                    url = USER_PAGE;

                  
                }
            }else {
                request.setAttribute("ERROR","Incorrect userID or password");
            }
            
        } catch (Exception e) {
            log("Error at LoginController: " + e.toString());
        }finally {
        
            request.getRequestDispatcher(url).forward(request, response);
        }
//
//            }
             
    } 
    }


