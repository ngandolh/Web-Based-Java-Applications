/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.home;

import dao.NhomTaiKhoanDAO;
import dao.TaiKhoanDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.NhomTaiKhoan;
import model.TaiKhoan;

/**
 *
 * @author ASUS
 */
@WebServlet(name = "register", urlPatterns = {"/home/register"})
public class register extends HttpServlet {
    private static final String ERROR = "/view/home/register.jsp";
    private static final String SUCCESS = "/view/home/login.jsp";
        TaiKhoan taikhoanmoi = new TaiKhoan();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        boolean trangthai =Boolean.parseBoolean(request.getParameter("trangthai"));
//        taikhoanmoi.setTrangthai(true);
//        request.setAttribute("USER",taikhoanmoi);

//        taikhoanmoi.setNhomtaikhoan(nhomtk);
                       RequestDispatcher rd = getServletContext().getRequestDispatcher("/view/home/register.jsp");
                  rd.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         String url = ERROR;
            String tentk = request.getParameter("tentk");
            String matkhau = request.getParameter("matkhau");
            String email = request.getParameter("email");
//            boolean trangthai =Boolean.parseBoolean(request.getParameter("trangthai"));
            String confirm=request.getParameter("confirm");
        try {

         NhomTaiKhoanDAO acc = new NhomTaiKhoanDAO();
         String us="US";
        NhomTaiKhoan nhomtk = acc.details(us);
            boolean checkValidation = true;
            TaiKhoanDAO dao = new TaiKhoanDAO();
            //kt userID [3,10]
            if (tentk.length() < 3 || tentk.length() > 10) {
                taikhoanmoi.setTentk("Fullname must be in[2,20]");
                checkValidation = false;
            }
             
            if (matkhau.length()<2 || matkhau.length()>50) {
                taikhoanmoi.setMatkhau("matkhau must be [2,50]");
                checkValidation = false;

            }
            if(!confirm.equals(matkhau)){
                taikhoanmoi.setConfirm("mat khau khong trung");
                checkValidation=false;
            }
            if (checkValidation==true) {

                TaiKhoan user = new TaiKhoan(tentk, matkhau, true, email,nhomtk);
                //         boolean checkInsert = dao.insert(user);
                boolean checkInsert = dao.insert(user);
                if (checkInsert==false) {
                    url = SUCCESS;
                }
            } else {
               
                request.setAttribute("USER_ERROR",taikhoanmoi);
            }

        } catch (Exception e) {
            log("Error at create: " + e.toString());
            if (e.toString().contains("duplicate")) {
                taikhoanmoi.setTentk("Trung ten roi kia!!!");
                request.setAttribute("USER_ERROR",taikhoanmoi);
            }
        } 
        finally {
            request.getRequestDispatcher(url).forward(request, response);
        }
    }


}
