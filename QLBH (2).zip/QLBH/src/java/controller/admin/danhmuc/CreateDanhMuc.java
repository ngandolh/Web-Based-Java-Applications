/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.admin.danhmuc;

import dao.DanhMucDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import model.DanhMuc;

/**
 *
 * @author ADMIN
 */import javax.servlet.http.HttpServletRequest;

@WebServlet(name = "CreateDanhMuc", urlPatterns = {"/home/create"})
public class CreateDanhMuc extends HttpServlet {

  private DanhMucDAO objectDao = new DanhMucDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {        
        
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/view/admin/danhmuc/create.jsp");
        rd.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String madm = request.getParameter("madm");
        String tendm = request.getParameter("tendm");
        Boolean trangthai = true;
        
        
        try{
            DanhMuc item = new DanhMuc(madm, tendm, trangthai);
            objectDao.create(item);
            response.sendRedirect(request.getContextPath() + "/home/indexdanhmuc");
        } catch (Exception ex) {
         Logger.getLogger(CreateDanhMuc.class.getName()).log(Level.SEVERE, null, ex);
     }
    }

   

  

}
