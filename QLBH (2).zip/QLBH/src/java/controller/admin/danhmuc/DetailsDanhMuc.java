/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.admin.danhmuc;

import controller.admin.nhacungcap.DetailsNhaCungCap;
import controller.home.Details;
import dao.SanPhamDAO;
import dao.SanPhamDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.SanPham;
import model.SanPham;

/**
 *
 * @author ADMIN
 */
@WebServlet(name = "DetailsDanhMuc", urlPatterns = {"/home/detaildanhmuc"})
public class DetailsDanhMuc extends HttpServlet {

//    private final SanPhamDAO code = new SanPhamDAO();
//
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        try {
//            List<SanPham> listItem = code.readAll();
//            String _code = request.getParameter("madm");
//            SanPham p = new SanPham();
//            for (SanPham x : listItem) {
//                if (x.getDanhmuc().getMadm().equals(_code)) {
//                    p = x;
//                    request.setAttribute("detailItem", listItem);
//                }
//            }
//
//            RequestDispatcher rd = getServletContext().getRequestDispatcher("/view/admin/danhmuc/details.jsp");
//            rd.forward(request, response);
//        } catch (Exception ex) {
//            Logger.getLogger(Details.class.getName()).log(Level.SEVERE, null, ex);
//        }
    
    private final SanPhamDAO code = new SanPhamDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String _code = request.getParameter("madm");
            List<SanPham> listItem = code.detailSanPham(_code);

            request.setAttribute("listItem", listItem);

            RequestDispatcher rd = getServletContext().getRequestDispatcher("/view/admin/danhmuc/details.jsp");
            rd.forward(request, response);
        } catch (IOException | ServletException ex) {
            Logger.getLogger(DetailsNhaCungCap.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    }


