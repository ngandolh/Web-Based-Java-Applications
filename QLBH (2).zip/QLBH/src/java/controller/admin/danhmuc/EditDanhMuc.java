/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.admin.danhmuc;

import dao.DanhMucDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DanhMuc;

/**
 *
 * @author ADMIN
 */
@WebServlet(name = "EditDanhMuc", urlPatterns = {"/home/editdanhmuc"})
public class EditDanhMuc extends HttpServlet {

    private DanhMucDAO objectDao=new DanhMucDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       try {
           String madm=request.getParameter("madm");
           DanhMuc item=objectDao.details(madm);
           
           request.setAttribute("item", item);
        RequestDispatcher rd= getServletContext().getRequestDispatcher("/view/admin/danhmuc/edit.jsp");
        rd.forward(request, response);
              }catch(Exception ex) {
        Logger.getLogger(EditDanhMuc.class.getName()).log(Level.SEVERE, null, ex);
    }
}


    @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    
      String madm = request.getParameter("madm");
        String tendm = request.getParameter("tendm");
        Boolean trangthai = true;
    try {
        DanhMuc item = new DanhMuc(madm, tendm, trangthai);
        objectDao.update(item);
        response.sendRedirect(request.getContextPath() + "/home/indexdanhmuc");
    } catch ( NumberFormatException ex ) {
            Logger.getLogger(EditDanhMuc.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
