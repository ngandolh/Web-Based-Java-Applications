/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.admin.nhacungcap;

import controller.admin.danhmuc.CreateDanhMuc;
import dao.DanhMucDAO;
import dao.NhaCungCapDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DanhMuc;
import model.NhaCungCap;

/**
 *
 * @author ADMIN
 */
@WebServlet(name = "CreateNhaCungCap", urlPatterns = {"/home/createnhacungcap"})
public class CreateNhaCungCap extends HttpServlet {

    private NhaCungCapDAO objectDao = new NhaCungCapDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {        
        
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/view/admin/nhacungcap/create.jsp");
        rd.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String mancc = request.getParameter("mancc");
        String tenncc = request.getParameter("tenncc");
        String diachi = request.getParameter("diachi");
        Boolean trangthai = true;
        
        
        try{
            NhaCungCap item = new NhaCungCap(mancc, tenncc,diachi, trangthai);
            objectDao.create(item);
            response.sendRedirect(request.getContextPath() + "/indexnhacungcap");
        } catch (Exception ex) {
         Logger.getLogger(CreateNhaCungCap.class.getName()).log(Level.SEVERE, null, ex);
     }
    }

   

}
