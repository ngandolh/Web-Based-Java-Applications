/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.admin.nhacungcap;

import dao.NhaCungCapDAO;
import dao.SanPhamDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.NhaCungCap;
import model.SanPham;

/**
 *
 * @author ADMIN
 */
@WebServlet( urlPatterns = {"/home/indexnhacungcap"})
public class IndexNhaCungCap extends HttpServlet {

    private final NhaCungCapDAO objectDao = new NhaCungCapDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

       try {
            List<NhaCungCap> listItem = objectDao.read();
            request.setAttribute("listItem", listItem);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/view/admin/nhacungcap/index.jsp");
            rd.forward(request, response);
        } catch (Exception ex) {
            Logger.getLogger(IndexNhaCungCap.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

 

}