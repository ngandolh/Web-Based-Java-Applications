/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.admin.sanpham;

import controller.home.Details;
import dao.SanPhamDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.SanPham;

/**
 *
 * @author Asus
 */
@WebServlet(name = "DetailsSanPham", urlPatterns = {"/home/detailsanpham"})
public class DetailsSanPham extends HttpServlet {

    private final SanPhamDAO code = new SanPhamDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            List<SanPham> listItem = code.readAll();
            String _code = request.getParameter("masp");
            SanPham p = new SanPham();
            for (SanPham x : listItem) {
                if (x.getMasp().equals(_code)) {
                    p = x;
                }
            }
            request.setAttribute("detailItem", p);
            request.setAttribute("img", p.getHinhanh());
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/view/home/detail.jsp");
            rd.forward(request, response);
        } catch (IOException | ServletException ex) {
            System.out.println(ex);
            Logger.getLogger(Details.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


}
