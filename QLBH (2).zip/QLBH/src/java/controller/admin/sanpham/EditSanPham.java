/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.admin.sanpham;

import dao.DanhMucDAO;
import dao.NhaCungCapDAO;
import dao.SanPhamDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DanhMuc;
import model.NhaCungCap;
import model.SanPham;

/**
 *
 * @author ADMIN
 */
@WebServlet(name = "EditSanPham", urlPatterns = {"/home/editsanpham"})
public class EditSanPham extends HttpServlet {

   
   
    private final SanPhamDAO objectDao = new SanPhamDAO();
    private final NhaCungCapDAO dao = new NhaCungCapDAO();
    private final DanhMucDAO DanhMucdao = new DanhMucDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String id = request.getParameter("Id");
            SanPham item = objectDao.details(id);

            request.setAttribute("item", item);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/view/admin/sanpham/edit.jsp");
            rd.forward(request, response);
        } catch (Exception ex) {
            Logger.getLogger(EditSanPham.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String _masp = request.getParameter("masp");
        String _tensp = request.getParameter("tensp");
        String _mota = request.getParameter("mota");
        int _soluong = Integer.parseInt(request.getParameter("soluong"));
        double _dongia = Double.parseDouble(request.getParameter("dongia"));
        String hinhanh = request.getParameter("hinhanh");
        Boolean _trangthai = true;

        String _mancc = request.getParameter("mancc");
        String _madm = request.getParameter("madm");
        NhaCungCap mancc = dao.details(_mancc);
        DanhMuc madm = DanhMucdao.details(_madm);
        try {
            SanPham item = new SanPham(_masp, _tensp, _mota, _soluong, _dongia, hinhanh, _trangthai, madm, mancc);

            objectDao.update(item);
            request.setAttribute("item", item);
            response.sendRedirect(request.getContextPath() + "/home/indexsanpham");
        } catch (NumberFormatException ex) {
            Logger.getLogger(EditSanPham.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
