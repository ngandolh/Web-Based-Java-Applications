/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.admin.sanpham;

import dao.DanhMucDAO;
import dao.NhaCungCapDAO;
import dao.SanPhamDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DanhMuc;
import model.NhaCungCap;
import model.SanPham;

/**
 *
 * @author ADMIN
 */
@WebServlet(name = "CreateSanPham", urlPatterns = {"/home/createsanpham"})
public class CreateSanPham extends HttpServlet {
    private final SanPhamDAO objectDao = new SanPhamDAO();
    private final NhaCungCapDAO dao = new NhaCungCapDAO();
    private final DanhMucDAO DanhMucdao = new DanhMucDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        RequestDispatcher rd = getServletContext().getRequestDispatcher("/view/admin/sanpham/create.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String masp = request.getParameter("masp");
        String tensp = request.getParameter("tensp");
        String mota = request.getParameter("mota");
        int soluong = Integer.parseInt(request.getParameter("soluong"));
        double dongia = Double.parseDouble(request.getParameter("dongia"));
        String hinhanh = request.getParameter("hinhanh");
        boolean trangthai = true;

        String _mancc = request.getParameter("mancc");
        String _madm = request.getParameter("madm");
        NhaCungCap mancc = dao.details(_mancc);
        DanhMuc madm = DanhMucdao.details(_madm);

        try {
            SanPham item = new SanPham(masp, tensp, mota, soluong, dongia, hinhanh, trangthai, madm, mancc);
            objectDao.create(item);
           
        } catch (Exception ex) {
            Logger.getLogger(CreateSanPham.class.getName()).log(Level.SEVERE, null, ex);
        } finally{
             response.sendRedirect(request.getContextPath() + "/home/indexsanpham");
        }
    }

}
