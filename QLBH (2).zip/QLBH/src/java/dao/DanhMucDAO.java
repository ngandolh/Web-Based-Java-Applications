/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import util.DBContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.DanhMuc;

/**
 *
 * @author Admin
 */
public class DanhMucDAO implements ICrud<String,DanhMuc>{
    List<DanhMuc> listItems;

//    public DanhMucDAO() {
//        listItems = new ArrayList<>();
//    }

    public DanhMucDAO(List<DanhMuc> listItems) {
        this.listItems = listItems;
    }

    public List<DanhMuc> getListItems() {
        return listItems;
    }

    public void setListItems(List<DanhMuc> listItems) {
        this.listItems = listItems;
    }
    private DBContext db;

    public DBContext getDb() {
        return db;
    }

    public void setDb(DBContext db) {
        this.db = db;
    }
      public DanhMucDAO (){
        db = new DBContext();
    }
 


    @Override
    public List<DanhMuc> read() {
        List<DanhMuc> listItem = new  ArrayList<>();
        
        try{
            String sql = "SELECT * FROM tblDanhMuc";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                String _madm = rs.getString("madm");
                String _tendm = rs.getString("tendm");
                Boolean _trangthai = rs.getBoolean("trangthai");
                DanhMuc item = new DanhMuc(_madm, _tendm, _trangthai);
                listItem.add(item);
            }
        } catch(SQLException ex) {
            Logger.getLogger(DanhMucDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listItem;
    }
    
    public DanhMuc details(String id) {

        try {
            String sql = "SELECT * FROM tblDanhMuc WHERE  madm=?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String _madm = rs.getString("madm");
                String _tendm = rs.getString("tendm");
                boolean _trangthai = rs.getBoolean("trangthai");
                DanhMuc item = new DanhMuc(_madm, _tendm, _trangthai);
                return item;
            }
        } catch (SQLException ex) {
            Logger.getLogger(DanhMucDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
       public static void main(String[] args) {
        DanhMucDAO sp = new DanhMucDAO();
        DanhMuc s = sp.details("T001");
        System.out.println(s);
    }

    public void create(DanhMuc newItem) {
        try {
            String sql = "insert into tblDanhMuc(madm,tendm,trangthai) values(?,?,?)";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            
            stmt.setString(1, newItem.getMadm());
            stmt.setString(2, newItem.getTendm());
            stmt.setBoolean(3, newItem.isTrangthai());
            
            stmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DanhMucDAO.class.getName()).log(Level.SEVERE,null,ex);
        }
    }
    //    delete from .... where madm =..
    public void delete(String madm) {
        String sql = "delete from tblDanhMuc where madm=?";
        try {
            PreparedStatement st = db.getConn().prepareStatement(sql);
            st.setString(1, madm);
            st.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
   //  Update
    public void update(DanhMuc edittedItem) {
        try {
            String sql = "Update tblDanhMuc Set tendm=?,  trangthai=? Where madm=?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            
            stmt.setString(1, edittedItem.getTendm());
            stmt.setBoolean(2, edittedItem.isTrangthai());
            stmt.setString(3, edittedItem.getMadm());
            
            stmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DanhMucDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
