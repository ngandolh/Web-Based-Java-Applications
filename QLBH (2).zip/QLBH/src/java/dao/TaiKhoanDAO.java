/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import util.DBContext;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;
import model.DanhMuc;
import model.NhaCungCap;
import model.NhomTaiKhoan;
import model.SanPham;
import model.TaiKhoan;

/**
 *
 * @author ASUS
 */
public class TaiKhoanDAO implements ICrud<String,TaiKhoan>{
        List<TaiKhoan> listItems;

    Connection conn = null;
    PreparedStatement ps=null;
    ResultSet rs = null;
    
    private DBContext db;

//    public TaiKhoanDAO() {
//    }

    public TaiKhoanDAO(DBContext db) {
        this.db = db;
    }

    public DBContext getDb() {
        return db;
    }

    public void setDb(DBContext db) {
        this.db = db;
    }

    public List<TaiKhoan> getListItems() {
        return listItems;
    }

    public void setListItems(List<TaiKhoan> listItems) {
        this.listItems = listItems;
    }

    public TaiKhoanDAO(List<TaiKhoan> listItems) {
        this.listItems = listItems;
    }

    public TaiKhoanDAO(List<TaiKhoan> listItems, DBContext db) {
        this.listItems = listItems;
        this.db = db;
    }
    public TaiKhoanDAO() {
        db = new DBContext();
    }
private final NhomTaiKhoanDAO dao = new NhomTaiKhoanDAO();
    @Override
    public List<TaiKhoan> read() {
 List<TaiKhoan> listItems = new ArrayList<>();
            try {
               
            String sql = "select * from tblTaiKhoan";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery(); 
            while (rs.next()) {
   
                String tentk=rs.getString("tentk");
                String matkhau=rs.getString("matkhau");
//                Boolean trangthai = rs.getBoolean("trangthai");
//                String email=rs.getString("email");
//                String _nhomtk = rs.getString("nhomtk");
//                NhomTaiKhoan nhomtk =dao.details(_nhomtk);
                TaiKhoan item = new TaiKhoan(tentk,matkhau);
                listItems.add(item);
            }
        } catch (SQLException ex) {
            Logger.getLogger(TaiKhoanDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listItems;
    }
//public static void main(String[] args) throws SQLException {
//        TaiKhoanDAO acc = new TaiKhoanDAO();
//        System.out.println(acc.read());}
    @Override
    public TaiKhoan details(String id) {
try {
            String sql = "SELECT * FROM tblTaiKhoan WHERE tentk=?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
   
                String tentk=rs.getString("tentk");
                String matkhau=rs.getString("matkhau");
                Boolean trangthai = rs.getBoolean("trangthai");
//                String nhomtk=rs.getString("nhomtk");
                String email=rs.getString("email");
                
                String _nhomtk = rs.getString("nhomtk");
                NhomTaiKhoan nhomtk =dao.details(_nhomtk);
                TaiKhoan item = new TaiKhoan(tentk,matkhau,trangthai,email,nhomtk);
                return item;
            }
        } catch (SQLException ex) {
            Logger.getLogger(TaiKhoanDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public void create(TaiKhoan newItem) {
String sql = "insert into tblTaiKhoan values (?,?,?,?,?)";
                   
                   
        try {
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            stmt.setString(1, newItem.getTentk());
            stmt.setString(2, newItem.getMatkhau());
            stmt.setBoolean(3, newItem.isTrangthai());
            stmt.setString(4, newItem.getEmail());   
            stmt.setObject(5, newItem.getNhomtaikhoan());

            stmt.executeUpdate(); // dùng khi muốn thêm, sửa, xóa
        } catch (SQLException ex) {
            Logger.getLogger(TaiKhoanDAO.class.getName()).log(Level.SEVERE, null, ex);
        }    }

    @Override
    public void update(TaiKhoan edittedItem) {
try {
        String sql = "update tblTaiKhoan set matkhau=?,trangthai=?,email=?, nhomtaikhoan=? where tentk=?";
        PreparedStatement stmt = db.getConn().prepareStatement(sql);
            
            stmt.setString(1, edittedItem.getMatkhau());
            stmt.setBoolean(2, edittedItem.isTrangthai());
            stmt.setString(3, edittedItem.getEmail());   
            stmt.setObject(4, edittedItem.getNhomtaikhoan());
            stmt.setString(5, edittedItem.getTentk());
        stmt.executeUpdate();
    } catch (SQLException ex) {
        Logger.getLogger(TaiKhoanDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void delete(String id) {
   String sql = "delete from tblTaiKhoan where tentk=?";      
        try {
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            stmt.setString(1, id);
            stmt.executeUpdate(); // thêm sua xoa thi dung lenh nay 
        } catch (SQLException ex) {
            Logger.getLogger(TaiKhoanDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     public TaiKhoan checkLogin(String tentk, String matkhau) throws  SQLException{
        TaiKhoan user = null;
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        String sql = "  SELECT * from tblTaiKhoan\n" +
" WHERE tentk=? AND matkhau=? and trangthai=1";  
        try {
            conn = db.getConn();
            if (conn != null) {
                PreparedStatement stmt = db.getConn().prepareStatement(sql);
                stmt.setString(1, tentk);
                stmt.setString(2, matkhau);
                rs = stmt.executeQuery();
                if (rs.next()) {
                    String email = rs.getString("email");
                     String _nhomtk = rs.getString("nhomtk");
                NhomTaiKhoan nhomtk =dao.details(_nhomtk);
                    return (TaiKhoan)new TaiKhoan(tentk, matkhau, true, email,nhomtk);
//                    return (TaiKhoan)new TaiKhoan(rs.getString(1), rs.getString(2), rs.getBoolean(3), rs.getString(4),rs.getObject(email, type));
                    
                }
            }
            
              
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
     public static void main(String[] args) throws SQLException {
        TaiKhoanDAO dao= new TaiKhoanDAO();
        TaiKhoan list = dao.checkLogin("tem", "111");
         System.out.println(list);
    }

      public boolean checkLogin1(String tentk, String matkhau) throws  SQLException{
        boolean result= false;
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
         String sql = "  SELECT tblTaikhoan WHERE tentk=? AND matkhau=? AND trangthai=1"; 
        try {
            conn = db.getConn();
            if (conn != null) {
 PreparedStatement stmt = db.getConn().prepareStatement(sql);
                stmt.setString(1, tentk);
                stmt.setString(2, matkhau);
                rs = stmt.executeQuery();
                if (rs.next()) {
                    result = true;
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if (rs!= null) rs.close();
            if (ptm!= null) ptm.close();
            if (conn!= null) conn.close();
        }
        return result;
    }
           private static final String CHECK_DUPLICATE="SELECT tentk FROM tblTaiKhoan WHERE tentk=?";
    public boolean checkDuplicate(String tentk) throws  SQLException{
        boolean check = false;
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        
        try {
            conn = db.getConn();
            if (conn != null) {
                ptm= conn.prepareStatement(CHECK_DUPLICATE);
                ptm.setString(1, tentk);       
                rs = ptm.executeQuery();
                if (rs.next()) {
                    check = true; 
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if (rs!= null) rs.close();
            if (ptm!= null) ptm.close();
            if (conn!= null) conn.close();
        }
        return check;
    }
      private static final String INSERT="INSERT INTO tblTaiKhoan(tentk, matkhau, email, trangthai,nhomtk) VALUES(?,?,?,?,?)";
     public boolean insert(TaiKhoan user) throws SQLException, ClassNotFoundException, NamingException{
        boolean check= false;
        Connection conn = null;
        PreparedStatement ptm = null;
        
        try {
            conn= db.getConn();
            if (conn != null) {
                ptm= conn.prepareStatement(INSERT);
                ptm.setString(1, user.getTentk());
                ptm.setString(2, user.getMatkhau());
                ptm.setString(3, user.getEmail());
                ptm.setBoolean(4, user.isTrangthai());
                ptm.setObject(5, user.getNhomtaikhoan().getNhomtk());

                ptm.executeUpdate();
            } 
        } finally{
            if (ptm!= null) ptm.close();
            if (conn!= null) conn.close();
        }
        return check;
    }
     //     public static void main(String[] args) throws SQLException {
//        TaiKhoanDAO acc = new TaiKhoanDAO();
//        TaiKhoan account = acc.checkLogin("admin", "123");
//         System.out.println(account.getTentk());
//    }
    }
    

