/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.NhomTaiKhoan;
import util.DBContext;

/**
 *
 * @author ASUS
 */
public class NhomTaiKhoanDAO implements ICrud<String,NhomTaiKhoan>{
        List<NhomTaiKhoan> listItems;

    Connection conn = null;
    PreparedStatement ps=null;
    ResultSet rs = null;
    
    private DBContext db;

    public DBContext getDb() {
        return db;
    }

    public void setDb(DBContext db) {
        this.db = db;
    }
//    public NhomTaiKhoanDAO() {
//        List<NhomTaiKhoan> listItems;
//    }

    public NhomTaiKhoanDAO(List<NhomTaiKhoan> listItems) {
        this.listItems = listItems;
    }

    public List<NhomTaiKhoan> getListItems() {
        return listItems;
    }

    public void setListItems(List<NhomTaiKhoan> listItems) {
        this.listItems = listItems;
    }
        
    public NhomTaiKhoanDAO() {
        db = new DBContext();
    }
    @Override
    public List<NhomTaiKhoan> read() {
        List<NhomTaiKhoan> listItem = new ArrayList<>();

        try {
            String sql = "SELECT * FROM tblNhomTaiKhoan";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String nhomtk = rs.getString("nhomtk");
                String mota = rs.getString("mota");
                Boolean trangthai = rs.getBoolean("trangthai");
                NhomTaiKhoan item = new NhomTaiKhoan(nhomtk, mota, trangthai);
                listItem.add(item);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NhomTaiKhoanDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listItem;
    }

    @Override
    public NhomTaiKhoan details(String id) {
     
        try {
            String sql = "SELECT * FROM tblNhomTaiKhoan WHERE nhomtk=?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String nhomtk = rs.getString("nhomtk");
                String mota = rs.getString("mota");
                Boolean trangthai = rs.getBoolean("trangthai");
                NhomTaiKhoan item = new NhomTaiKhoan(nhomtk, mota, trangthai);
                return item;
            }
        } catch (SQLException ex) {
            Logger.getLogger(NhomTaiKhoanDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
public static void main(String[] args) throws SQLException {
        NhomTaiKhoanDAO acc = new NhomTaiKhoanDAO();
        NhomTaiKhoan a = acc.details("US");
        System.out.println(a.getNhomtk());

}

    @Override
    public void create(NhomTaiKhoan newItem) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(NhomTaiKhoan edittedItem) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
