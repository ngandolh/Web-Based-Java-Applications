/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.DanhMuc;
import model.NhaCungCap;
import model.SanPham;
import util.DBContext;

/**
 *
 * @author Asus
 */
public class NhaCungCapDAO implements ICrud<String, NhaCungCap> {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    private DBContext db;

    public DBContext getDb() {
        return db;
    }

    public void setDb(DBContext db) {
        this.db = db;
    }

    public NhaCungCapDAO(DBContext db) {
        this.db = db;
    }

    public NhaCungCapDAO() {
        this.db = new DBContext();
    }

    List<NhaCungCap> listItems;

//    public NhaCungCapDAO() {
//        listItems = new ArrayList<>();
//    }
    public NhaCungCapDAO(List<NhaCungCap> listItems) {
        this.listItems = listItems;
    }

    public List<NhaCungCap> getListItems() {
        return listItems;
    }

    public void setListItems(List<NhaCungCap> listItems) {
        this.listItems = listItems;
    }

    @Override
    public List<NhaCungCap> read() {
        List<NhaCungCap> listItem = new ArrayList<>();

        try {
            String sql = "select * from tblNhaCungCap";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String _mancc = rs.getString("mancc");
                String _tenncc = rs.getString("tenncc");
                String _diachi = rs.getString("diachi");
                boolean _trangthai = rs.getBoolean("trangthai");
                NhaCungCap item = new NhaCungCap(_mancc, _tenncc, _diachi, _trangthai);
                listItem.add(item);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NhaCungCapDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listItem;
    }

    @Override
    public NhaCungCap details(String id) {
        try {
            String sql = "SELECT * FROM tblNhaCungCap WHERE  mancc=?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String _mancc = rs.getString("mancc");
                String _tenncc = rs.getString("tenncc");
                String _diachi = rs.getString("diachi");
                boolean _trangthai = rs.getBoolean("trangthai");
                NhaCungCap item = new NhaCungCap(_mancc, _tenncc, _diachi, _trangthai);
                return item;
            }
        } catch (SQLException ex) {
            Logger.getLogger(NhaCungCapDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

   

    public NhaCungCap detailsBy(String id) {
        try {
            String sql = "SELECT ncc.mancc \n"
                    + "FROM tblNhaCungCap ncc\n"
                    + "Inner join tblSanPham sp\n"
                    + "on ncc.mancc = sp.mancc\n"
                    + "WHERE masp=?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String _mancc = rs.getString("mancc");
                NhaCungCap item = new NhaCungCap(_mancc);
                return item;
            }
        } catch (SQLException ex) {
            Logger.getLogger(DanhMucDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public void create(NhaCungCap newItem) {
        try {
            String sql = "insert into tblNhaCungCap(mancc, tenncc, diachi, trangthai) values(?,?,?,?)";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);

            stmt.setString(1, newItem.getMancc());
            stmt.setString(2, newItem.getTenncc());
            stmt.setString(3, newItem.getDiachi());
            stmt.setBoolean(4, newItem.isTrangthai());

            stmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DanhMucDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void update(NhaCungCap edittedItem) {
        try {
            String sql = "Update tblNhaCungCap Set tenncc=?, diachi=?, trangthai=? Where mancc=?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);

            stmt.setString(1, edittedItem.getTenncc());
            stmt.setString(2, edittedItem.getDiachi());
            stmt.setBoolean(3, edittedItem.isTrangthai());
            stmt.setString(4, edittedItem.getMancc());

            stmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DanhMucDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void delete(String id) {
        String sql = "delete from tblNhaCungCap where mancc=?";
        try {
            PreparedStatement st = db.getConn().prepareStatement(sql);
            st.setString(1, id);
            st.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String[] args) throws SQLException {
        NhaCungCapDAO ncc = new NhaCungCapDAO();
        String mancc = "C04";
        NhaCungCap n = ncc.detailsBy("L01");;
        System.out.println(n);

    }

}