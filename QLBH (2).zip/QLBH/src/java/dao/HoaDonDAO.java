/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import util.DBContext;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.HoaDon;

/**
 *
 * @author Admin
 */
public class HoaDonDAO implements ICrud<String,HoaDon>{
    List<HoaDon> listItems;

    public HoaDonDAO() {
        listItems = new ArrayList<>();
    }

    public HoaDonDAO(List<HoaDon> listItems) {
        this.listItems = listItems;
    }

    public List<HoaDon> getListItems() {
        return listItems;
    }

    public void setListItems(List<HoaDon> listItems) {
        this.listItems = listItems;
    }
    private DBContext db;

    public DBContext getDb() {
        return db;
    }

    public void setDb(DBContext db) {
        this.db = db;
    }


    @Override
    public List<HoaDon> read() {
        List<HoaDon> listItem = new  ArrayList<>();
        
        try{
            String sql = "SELECT * FROM tblHoaDon";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                String _mahd = rs.getString("mahd");
                Date _ngaydh = rs.getDate("ngaydh");
                int _trangthaixuly=rs.getInt("trangthaixuly");
                String _makh=rs.getString("makh");
               
                HoaDon item = new HoaDon(_mahd, _ngaydh, _trangthaixuly, _makh);
                listItem.add(item);
            }
        } catch(SQLException ex) {
            Logger.getLogger(HoaDonDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listItem;
    }
    
    public HoaDon details(String id) {
        
        try{
            String sql = "SELECT * FROM tblHoaDon WHERE mahd=?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                 String _mahd = rs.getString("mahd");
                Date _ngaydh = rs.getDate("ngaydh");
                int _trangthaixuly=rs.getInt("trangthaixuly");
                String _makh=rs.getString("makh");
               
                HoaDon item = new HoaDon(_mahd, _ngaydh, _trangthaixuly, _makh);
                return item;
            }
        } catch(SQLException ex) {
            Logger.getLogger(HoaDonDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public void create(HoaDon newItem) {
        try {
            String sql = "insert into tblHoaDon(mahd,ngaydh,trangthaixuly,makh) values(?,?,?,?)";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            
            stmt.setString(1, newItem.getMahd());
            stmt.setDate(2, newItem.getNgaydh());
            stmt.setInt(3, newItem.getTrangthaixuly());
            stmt.setString(4,newItem.getMakh());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(HoaDonDAO.class.getName()).log(Level.SEVERE,null,ex);
        }
    }
    //    delete from .... where mahd =..
    public void delete(String mahd) {
        String sql = "delete from tblHoaDon where mahd=?";
        try {
            PreparedStatement st = db.getConn().prepareStatement(sql);
            st.setString(1, mahd);
            st.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
   //  Update
    public void update(HoaDon edittedItem) {
        try {
            String sql = "Update tblHoaDon Set Ngaydh=?, trangthaixuly=?, makh=? Where mahd=?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            
           stmt.setString(1, edittedItem.getMahd());
            stmt.setDate(2, edittedItem.getNgaydh());
            stmt.setInt(3, edittedItem.getTrangthaixuly());
            stmt.setString(4,edittedItem.getMakh());
            
            stmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(HoaDonDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
