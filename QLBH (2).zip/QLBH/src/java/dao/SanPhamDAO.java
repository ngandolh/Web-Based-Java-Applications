/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import util.DBContext;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.DanhMuc;
import model.NhaCungCap;
import model.SanPham;

/**
 *
 * @author Admin
 */
public class SanPhamDAO implements ICrud<String, SanPham> {


    List<SanPham> listItems;

//    public SanPhamDAO() {
//        listItems = new ArrayList<>();
//    }
    public SanPhamDAO(List<SanPham> listItems) {
        this.listItems = listItems;
    }

    public List<SanPham> getListItems() {
        return listItems;
    }

    public void setListItems(List<SanPham> listItems) {
        this.listItems = listItems;
    }
    private DBContext db;

    public DBContext getDb() {
        return db;
    }

    public void setDb(DBContext db) {
        this.db = db;
    }

    public SanPhamDAO() {
        db = new DBContext();
    }
    private final NhaCungCapDAO nhacungcapDAO = new NhaCungCapDAO();
    private final DanhMucDAO madmDAO = new DanhMucDAO();

    public List<SanPham> readAll() {
        List<SanPham> listItem = new ArrayList<>();

        try {
            String sql = "select sp.masp, sp.tensp, sp.mota, sp.soluong, sp.dongia, sp.hinhhanh, sp.trangthai, sp.madm, sp.mancc\n"
                    + "from tblSanPham sp\n"
                    + "inner join tblDanhMuc dm\n"
                    + "on sp.madm = dm.madm\n"
                    + "inner join tblNhaCungCap ncc\n"
                    + "on sp.mancc = ncc.mancc";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String _masp = rs.getString("masp");
                String _tensp = rs.getString("tensp");
                String _mota = rs.getString("mota");
                int _soluong = rs.getInt("soluong");
                double _dongia = rs.getDouble("dongia");
                String _hinhhanh = rs.getString("hinhhanh");
                boolean _trangthai = rs.getBoolean("trangthai");
//                Bảng tblDanhMuc, tblNhaCungCap
                String _mancc = rs.getString("mancc");
                String _madm = rs.getString("madm");
                NhaCungCap mancc = nhacungcapDAO.details(_mancc);
                DanhMuc madm = madmDAO.details(_madm);

                SanPham item = new SanPham(_masp, _tensp, _mota, _soluong, _dongia, _hinhhanh, _trangthai, mancc, madm);
                listItem.add(item);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DanhMucDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listItem;
    }
    public static void main(String[] args) {
        SanPhamDAO sp = new SanPhamDAO();
        sp.readAll();
        
        List<SanPham> list = sp.detailSanPham("T001");
        for (SanPham sanPham : list) {
            System.out.println(sanPham);
            
        }
        
    }

    public SanPham details(String id) {

        try {
            String sql = "SELECT * FROM tblSanPham WHERE masp=?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String _masp = rs.getString("masp");
                String _tensp = rs.getString("tensp");
                String _mota = rs.getString("mota");
                int _soluong = rs.getInt("soluong");
                Double _dongia = rs.getDouble("dongia");
                String _hinhhanh = rs.getString("hinhhanh");
                Boolean _trangthai = rs.getBoolean("trangthai");
                String _mancc = rs.getString("mancc");
                String _madm = rs.getString("madm");
                NhaCungCap mancc = nhacungcapDAO.details(_mancc);
                DanhMuc madm = madmDAO.details(_madm);

                SanPham item = new SanPham(_masp, _tensp, _mota, _soluong, _dongia, _hinhhanh, _trangthai, mancc, madm);
                return item;
            }
        } catch (SQLException ex) {
            Logger.getLogger(SanPhamDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

 

    public void create(SanPham newItem) {
        try {
            String sql = "insert into tblSanPham(masp,tensp,mota,soluong,dongia,hinhhanh,trangthai,nhacungcap,danhmuc) values(?,?,?,?,?,?,?,?,?)";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);

            stmt.setString(1, newItem.getMasp());
            stmt.setString(2, newItem.getTensp());
            stmt.setString(3, newItem.getMota());
            stmt.setInt(4, newItem.getSoluong());
            stmt.setDouble(5, newItem.getDongia());
            stmt.setString(6, newItem.getHinhanh());
            stmt.setBoolean(7, newItem.isTrangthai());
            stmt.setObject(8, newItem.getNhacungcap());
            stmt.setObject(9, newItem.getDanhmuc());

            stmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SanPhamDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //    delete from .... where masp =..
    public void delete(String masp) {
        String sql = "delete from tblSanPham where masp=?";
        try {
            PreparedStatement st = db.getConn().prepareStatement(sql);
            st.setString(1, masp);
            st.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    //  Update

    public void update(SanPham edittedItem) {
        try {
            String sql = "Update tblSanPham Set tensp=?,mota=?,soluong=?,dongia=?,hinhhanh=?,trangthai=?,nhacungcap=?,danhmuc=? Where masp=?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);

            stmt.setString(1, edittedItem.getTensp());
            stmt.setString(2, edittedItem.getMota());
            stmt.setInt(3, edittedItem.getSoluong());
            stmt.setDouble(4, edittedItem.getDongia());
            stmt.setString(5, edittedItem.getHinhanh());
            stmt.setBoolean(6, edittedItem.isTrangthai());
            stmt.setObject(7, edittedItem.getNhacungcap());
            stmt.setObject(8, edittedItem.getDanhmuc());
            stmt.setString(9, edittedItem.getMasp());

            stmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SanPhamDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

//    public SanPham getProductbyID(String productID) 
//            throws SQLException, NamingException {
//        
//        SanPham result = null;
////        Connection con = null;
//        PreparedStatement stmt = null;
//        ResultSet rs = null;
//        
//        try {
////            con = DBHelper.makeConnection();
////            if (con != null) {
//                String sqlStr = "select * \n"
//                        + "FROM Product p inner JOIN  Picture i ON p.picID = i.picID  inner JOIN Category c ON p.CategoryID = c.CategoryID\n"
//                        + "WHERE productID = ?";
////                stmt = con.prepareStatement(sqlStr);
//                stmt.setString(1, productID);
//                rs = stmt.executeQuery();
//                
//                while (rs.next()) {
//                    //get field/column
////                    String productID = rs.getString("productID");
//                    String proName = rs.getString("proName");
//                    String description = rs.getString("description");
//                    int yearPublish = rs.getInt("yearPublish");
//                    float price = rs.getFloat("price");
//                    String catgoryName = rs.getString("catgoryName");
//                    byte[] picData = rs.getBytes("picdata");
//                    String picID = rs.getString("picID");
//
//                    //Create DTO instance
//                    result = new SanPham(productID, proName, description, yearPublish, price, catgoryName, picID, picData);
//              return result;
////                }
//                
//            }
//        } finally {
//            if (rs != null) {
//                rs.close();
//            }
//            if (stmt != null) {
//                stmt.close();
//            }
////            if (con != null) {
////                con.close();
////            }
//        }
//        return result;
//    }
        public List<SanPham> detailsSanPham(String id) {
        List<SanPham> listItem = new ArrayList<>();
        try {
            String sql = "select s.mancc, s.madm, s.masp, s.tensp, s.soluong, s.trangthai, s.dongia, s.mota, s.hinhhanh\n"
                    + "from tblNhaCungCap n\n"
                    + "inner join tblSanPham s\n"
                    + "on n.mancc = s.mancc\n"
                    + "where n.mancc = ?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String _masp = rs.getString("masp");
                String _tensp = rs.getString("tensp");
                int _soluong = rs.getInt("soluong");
                boolean _trangthai = rs.getBoolean("trangthai");
                double _dongia = rs.getDouble("dongia");
                String _mota = rs.getString("mota");
                String _hinhhanh = rs.getString("hinhhanh");
                String _mancc = rs.getString("mancc");
                String _madm = rs.getString("madm");
                NhaCungCap mancc = nhacungcapDAO.details(_mancc);
                DanhMuc madm = madmDAO.details(_madm);
                SanPham item = new SanPham(_madm, _tensp, _mota, _soluong, _dongia, _hinhhanh, _trangthai, mancc, madm);
                listItem.add(item);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NhaCungCapDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listItem;
    }
          public List<SanPham> detailSanPham(String id) {
        List<SanPham> listItem = new ArrayList<>();
        try {
            String sql ="select  s.mancc, s.madm, s.masp, s.tensp, s.soluong, s.trangthai, s.dongia, s.mota, s.hinhhanh\n" +
"                    from tblDanhMuc n\n" +
"                     inner join tblSanPham s\n" +
"                     on n.madm = s.madm\n" +
"                     where n.madm = ?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String _masp = rs.getString("masp");
                String _tensp = rs.getString("tensp");
                int _soluong = rs.getInt("soluong");
                boolean _trangthai = rs.getBoolean("trangthai");
                double _dongia = rs.getDouble("dongia");
                String _mota = rs.getString("mota");
                String _hinhhanh = rs.getString("hinhhanh");
                String _mancc = rs.getString("mancc");
                String _madm = rs.getString("madm");
                NhaCungCap mancc = nhacungcapDAO.details(_mancc);
                DanhMuc madm = madmDAO.details(_madm);
                SanPham item = new SanPham(_madm, _tensp, _mota, _soluong, _dongia, _hinhhanh, _trangthai, mancc, madm);
                listItem.add(item);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NhaCungCapDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listItem;
    }
    @Override
    public List<SanPham> read() {
        List<SanPham> listItem = new ArrayList<>();

        try {
            String sql = "select masp, tensp, dongia\n"
                    + "From tblSanPham";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String _masp = rs.getString("masp");
                String _tensp = rs.getString("tensp");
                double _dongia = rs.getDouble("dongia");
//              String _hinhanh = rs.getString("hinhanh");
                SanPham item = new SanPham(_masp, _tensp, _dongia);
                listItem.add(item);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DanhMucDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listItem;
    }

    public List<SanPham> searchByName(String searchName) {
        List<SanPham> listItem = new ArrayList<>();

        try {
            //2.Create sql String
            String sql = "select *\n"
                    + "From tblSanPham\n"
                    + "where tensp like ?";
            //1.Get connection - 3.Create statement.
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            stmt.setNString(1, "%" + searchName + "%");
            //4.Execute Query
            ResultSet rs = stmt.executeQuery();
            //5.Process result
            while (rs.next()) {
                String _masp = rs.getString("masp");
                String _tensp = rs.getString("tensp");
                String _hinhhanh = rs.getString("hinhhanh");
                String _mota = rs.getString("mota");
                int _soluong = rs.getInt("soluong");
                double _dongia = rs.getDouble("dongia");
                boolean _trangthai = rs.getBoolean("trangthai");
                String _mancc = rs.getString("mancc");
                String _madm = rs.getString("madm");
                NhaCungCap mancc = nhacungcapDAO.details(_mancc);
                DanhMuc madm = madmDAO.details(_madm);

                SanPham item = new SanPham(_masp, _tensp, _mota, _soluong, _dongia, _hinhhanh, _trangthai, mancc, madm);
                listItem.add(item);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DanhMucDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listItem;
    }

    public SanPham findByID(String code) {
        Connection conn = null;
        PreparedStatement stmt = null;
        SanPham pro = null;
        try {
            String sql = "select * from tblSanPham where masp = ?";
            stmt = db.getConn().prepareStatement(sql);
            stmt.setString(1, code);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
//                pro = new Product();
//                pro.setCode(rs.getString(1));
//                pro.setName(rs.getString(2));
//                pro.setPrice(rs.setString(3));
                String _masp = rs.getString("masp");
                String _tensp = rs.getString("tensp");
                String _hinhanh = rs.getString("hinhhanh");
                String _mota = rs.getString("mota");
                int _soluong = rs.getInt("soluong");
                double _dongia = rs.getDouble("dongia");
                boolean _trangthai = rs.getBoolean("trangthai");
                String _mancc = rs.getString("mancc");
                String _madm = rs.getString("madm");
                NhaCungCap mancc = nhacungcapDAO.details(_mancc);
                DanhMuc madm = madmDAO.details(_madm);

                SanPham item = new SanPham(_masp, _tensp, _mota, _soluong, _dongia, _hinhanh, _trangthai, mancc, madm);
                return item;
            }
        } catch (Exception e) {
            System.out.println("Error:" + e.toString());
        } finally {
            try {
                stmt.close();
                conn.close();
            } catch (Exception e) {

            }
        }
        return pro;
    }

}