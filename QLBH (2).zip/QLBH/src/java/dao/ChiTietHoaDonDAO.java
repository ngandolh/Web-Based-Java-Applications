/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import util.DBContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.ChiTietHoaDon;

/**
 *
 * @author Admin
 */
public class ChiTietHoaDonDAO implements ICrud<String,ChiTietHoaDon>{
    List<ChiTietHoaDon> listItems;

    public ChiTietHoaDonDAO() {
        listItems = new ArrayList<>();
    }

    public ChiTietHoaDonDAO(List<ChiTietHoaDon> listItems) {
        this.listItems = listItems;
    }

    public List<ChiTietHoaDon> getListItems() {
        return listItems;
    }

    public void setListItems(List<ChiTietHoaDon> listItems) {
        this.listItems = listItems;
    }
    private DBContext db;

    public DBContext getDb() {
        return db;
    }

    public void setDb(DBContext db) {
        this.db = db;
    }


    @Override
    public List<ChiTietHoaDon> read() {
        List<ChiTietHoaDon> listItem = new  ArrayList<>();
        
        try{
            String sql = "SELECT * FROM tblChiTietHoaDon";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                String _mahd = rs.getString("mahd");
                String _masp = rs.getString("masp");
                int _soluong = rs.getInt("soluong");
                double _dongia=rs.getDouble("dongia");
                double _khuyenmai=rs.getDouble("khuyenmai");
                double _giatri=rs.getDouble("giatri");
                ChiTietHoaDon item = new ChiTietHoaDon(_mahd, _masp, _soluong,_dongia, _khuyenmai, _giatri);
                listItem.add(item);
            }
        } catch(SQLException ex) {
            Logger.getLogger(ChiTietHoaDonDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listItem;
    }
    
    public ChiTietHoaDon details(String id) {
        
        try{
            String sql = "SELECT * FROM tblChiTietHoaDon WHERE mahd=?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                String _mahd = rs.getString("mahd");
                String _masp = rs.getString("masp");
                int _soluong = rs.getInt("soluong");
                double _dongia=rs.getDouble("dongia");
                double _khuyenmai=rs.getDouble("khuyenmai");
                double _giatri=rs.getDouble("giatri");
                ChiTietHoaDon item = new ChiTietHoaDon(_mahd, _masp, _soluong,_dongia, _khuyenmai, _giatri);
                return item;
            }
        } catch(SQLException ex) {
            Logger.getLogger(ChiTietHoaDonDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public void create(ChiTietHoaDon newItem) {
        try {
            String sql = "insert into tblChiTietHoaDon(mahd,masp,soluong,dongia,khuyenmai,giatri) values(?,?,?,?)";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            
            stmt.setString(1, newItem.getMahd());
            stmt.setString(2, newItem.getMasp());
            stmt.setInt(3, newItem.getSoluong());
            stmt.setDouble(4, newItem.getDongia());
            stmt.setDouble(5, newItem.getKhuyenmai());
            stmt.setDouble(6, newItem.getGiatri());
   
            
            stmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ChiTietHoaDonDAO.class.getName()).log(Level.SEVERE,null,ex);
        }
    }
    //    delete from .... where mahd =..
    public void delete(String mahd) {
        String sql = "delete from tblChiTietHoaDon where mahd=?";
        try {
            PreparedStatement st = db.getConn().prepareStatement(sql);
            st.setString(1, mahd);
            st.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
   //  Update
    public void update(ChiTietHoaDon edittedItem) {
        try {
            String sql = "Update tblChiTietHoaDon Set masp=?, soluong=? dogia=? khuyenmai=? giatri=? Where mahd=?";
            PreparedStatement stmt = db.getConn().prepareStatement(sql);
            
             stmt.setString(1, edittedItem.getMahd());
            stmt.setString(2, edittedItem.getMasp());
            stmt.setInt(3, edittedItem.getSoluong());
            stmt.setDouble(4, edittedItem.getDongia());
            stmt.setDouble(5, edittedItem.getKhuyenmai());
            stmt.setDouble(6, edittedItem.getGiatri());
            
            stmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ChiTietHoaDonDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
