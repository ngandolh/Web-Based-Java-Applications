/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author ADMIN
 */
public class ChiTietHoaDon {
    private String mahd;
    private String masp;
    private int soluong;
    private double dongia;
    private double khuyenmai;
    private double giatri;

    public ChiTietHoaDon() {
    }

    public ChiTietHoaDon(String mahd, String masp, int soluong, double dongia, double khuyenmai, double giatri) {
        this.mahd = mahd;
        this.masp = masp;
        this.soluong = soluong;
        this.dongia = dongia;
        this.khuyenmai = khuyenmai;
        this.giatri = giatri;
    }

    public String getMahd() {
        return mahd;
    }

    public void setMahd(String mahd) {
        this.mahd = mahd;
    }

    public String getMasp() {
        return masp;
    }

    public void setMasp(String masp) {
        this.masp = masp;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    public double getDongia() {
        return dongia;
    }

    public void setDongia(double dongia) {
        this.dongia = dongia;
    }

    public double getKhuyenmai() {
        return khuyenmai;
    }

    public void setKhuyenmai(double khuyenmai) {
        this.khuyenmai = khuyenmai;
    }

    public double getGiatri() {
        return giatri;
    }

    public void setGiatri(double giatri) {
        this.giatri = giatri;
    }
    
}
