/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import dao.SanPhamDAO;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author ACER
 */
public class CartList implements Serializable {
//extends ArrayList<CartItem>
//    public void addToCart(String masp, int soluong) {
//        if (this.size() > 0) {
//            int found = containSp(masp);
//            if (found != -1) {
//                CartItem ci = this.get(found);
//                ci.setAmount(ci.getAmount() + soluong);
//            } else {
//                SanPhamDAO sd = new SanPhamDAO();
//                this.add(new CartItem(sd.details(masp), soluong));
//            }
//        } else {
//            SanPhamDAO sd = new SanPhamDAO();
//            this.add(new CartItem(sd.details(masp), soluong));
//        }
//    }
//    
//    public static void main(String[] args) {
//        CartItem list = new CartItem();
//        List<CartList> listItem = new ArrayList<>();
//        CartList listCard = new CartList();
//        listCard.addToCart("A01", 1);
//        listCard.addToCart("A01", 3);
//        System.out.println(listCard.get(0).getAmount());
//    }
//    public void delete(String masp){
//        if(this.size()>0){
//            int found = containSp(masp);
//            if(found!=-1){
//                this.remove(found);
//            }
//        }
//    }
//    private int containSp(String masp) {
//       for(int i=0; i<this.size();i++){
//           if(this.get(i).getSp().getMasp().equals(masp)){
//               return i;
//           }
//       }
//       return -1;
//    }
//    

    private String masp;
    private Map<String, Integer> items;

    public String getMasp() {
        return masp;
    }

    public void setMasp(String masp) {
        this.masp = masp;
    }

    public Map<String, Integer> getItems() {
        return items;
    }

      public void addItemToCart(String tensp) {
        if(this.items == null) this.items = new HashMap<String,Integer>();
        int quantity = 1;
        if(this.items.containsKey(tensp)) quantity = this.items.get(tensp) + 1;
        this.items.put(tensp, quantity);
    }
 

    public void removeItemFromCart(String tensp) {
        if (this.items == null) {
            return;
        }
        if (this.items.containsKey(tensp)) {
            this.items.remove(tensp);
            if (this.items.isEmpty()) {
                this.items = null;
            }
        }
    }

}
